package com.wesleymontcho.springtp2024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springtp2024Application {

	public static void main(String[] args) {
		SpringApplication.run(Springtp2024Application.class, args);
	}

}
